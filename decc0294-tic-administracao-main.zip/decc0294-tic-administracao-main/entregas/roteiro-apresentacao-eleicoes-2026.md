# Roteiro de apresentação — Nulos, brancos e os mais votados (Eleições 2026, 1º turno)

> **Status: RASCUNHO.** Este é o mapa da sua fala, não o texto pra decorar.
> Onde tem `[SUA DECISÃO]`, é você que fecha — eu não posso decidir por você.

**Arquivo do deck:** `apresentacao-eleicoes-2026-nulos-brancos.html`
**Duração alvo:** 12 a 15 min de fala + 8 min de dinâmica = **~20 min**
**Formato:** 13 telas, navegação por `←` `→`, `F11` pra tela cheia, botão "Exportar PDF" imprime tudo.

---

## 1. Mapa de tempo

| Bloco | Telas | Tempo | O que acontece |
|---|---|---|---|
| Abertura | 1–2 | 2 min | Gancho + método (fonte e limite) |
| Dinâmica 1 | 3 | 2 min | Levanta a mão: quem já anulou? |
| Diagnóstico | 4–5 | 3 min | O retrato + quiz relâmpago |
| Rankings | 6–7 | 3 min | Top 10 e a virada número × proporção |
| Armadilha | 8 | 2 min | Senado com 2 votos |
| Candidatos | 9–10 | 3 min | Abas por cargo + aposta da turma |
| Fechamento | 11–13 | 5 min | Dinâmica 60s, interpretação, limites, fontes |

Se atrasar, corte a **Dinâmica 3** (aposta). Nunca corte as telas **2** (limites) e **12** (limitações) — é o que o professor mais cobra.

---

## 2. Roteiro tela por tela

### Tela 1 — Capa
**Abre com:** "Quase 6 milhões de votos foram jogados no lixo em outubro. E o mais estranho: não foi acidente."
**Não leia os cards.** Deixe a imagem falar e já emenda a pergunta da direita.

> `[SUA DECISÃO]` Escolha se você quer abrir pelo número (6 milhões) ou pela pergunta ("o eleitor anula mais do que branqueia?"). A segunda opção prende mais a turma; a primeira impressiona mais a banca.

---

### Tela 2 — Método (não pule)
**Fala:** "Tudo que vocês vão ver saiu de dois arquivos oficiais do TSE. Nada foi estimado, nada veio de notícia, nada veio de IA."
Cite os dois nomes de arquivo em voz alta. Depois **aponte o card vermelho** e diga: "e tem um limite importante que eu vou repetir no final."

**Por que essa tela existe:** se alguém da banca perguntar "de onde veio isso?", a resposta já está na tela 2. Você ganha 30 segundos de credibilidade de graça.

---

### Tela 3 — Dinâmica 1: levanta a mão
**Como conduzir:**
1. Peça: "Levanta a mão quem já anulou um voto de propósito." Conte e clique no `+` da primeira linha.
2. Repita para as outras três opções, **uma por vez**.
3. Deixe as barras crescendo na tela enquanto fala.

**Frase de virada:** "Olha o tamanho disso. A gente tá falando de um comportamento comum, não de exceção."

⚠️ **Não deixe virar debate político.** Se alguém começar a justificar voto, corte: "aqui a gente tá olhando o comportamento, não o candidato."

> `[SUA DECISÃO]` Você pode pedir voto aberto ("quem anulou em 2022?") ou manter anônimo por mão levantada. Em turma grande, mão levantada rende mais.

---

### Tela 4 — O retrato
**Fala:** "De cada 100 votos pra presidente, 95 viraram voto de verdade. 3 foram nulos. 2 foram brancos."
Aponte a barra e depois a legenda: **"e olha o detalhe que ninguém comenta: nulo ganhou de branco em 26 das 27 unidades da federação."**

**Se perguntarem do RS:** "Sim, o Rio Grande do Sul é a única exceção — 148 mil brancos contra 131 mil nulos."

---

### Tela 5 — Quiz
**Como conduzir:** leia as 4 opções em voz alta e peça pra turma votar **antes** de clicar. Aí clica.

- Acertou? "Isso. Paraíba."
- Errou? "Não. E olha que a maioria erra — porque a intuição diz São Paulo, que é o maior. Só que maior não é o mesmo que proporcionalmente maior."

**Essa é a transição perfeita pra tela 7.** Use ela.

---

### Tela 6 — Top 10
**Fala:** "Paraíba, Alagoas, São Paulo, Bahia, Pernambuco. Repara: é Nordeste e Sudeste no topo."
Depois **vire pro lado direito e leia o card vermelho**: "e antes que alguém conclua que 'nordestino anula mais', isso é salto lógico. O dado é por estado, não por pessoa."

**Esse é o momento em que você mostra maturidade analítica.** A banca ama.

---

### Tela 7 — Número × proporção (a tela mais importante)
**Como conduzir:** comece em "Por número absoluto" e leia os 3 primeiros. Depois clique em "Por proporção (%)" **e deixe a ordem virar na frente da turma**.

**Fala:** "Mesma base de dados. Duas perguntas diferentes. Duas respostas diferentes. Nenhuma das duas está errada."

**Frase de ouro:** "Quando alguém te dá um ranking, a primeira pergunta é: ranking de quê?"

> `[SUA DECISÃO]` Essa é a sua tese ou só um alerta metodológico? Se for tese, repita ela no fechamento.

---

### Tela 8 — A armadilha do Senado
**Fala:** "Aqui eu quase errei. O Ceará aparecia com mais votos do que gente apta a votar. Impossível."
"Fui atrás: 11,8 milhões de votos pra senador contra 5,9 milhões pra governador. Exatamente o dobro. Por quê? **Duas cadeiras por estado, dois votos por eleitor.**"

**Feche com:** "Número estranho não se corrige no chute. Se investiga."

**Por que contar esse erro:** mostrar o erro que você **encontrou e corrigiu** vale mais que fingir que acertou de primeira.

---

### Tela 9 — Candidatos (abas)
**Como conduzir:** comece em Presidente, leia os dois primeiros, e **clique nas abas** mostrando que o campeão muda.

**Fala:** "O campeão da eleição não é o mesmo em todo cargo. Flávio fez 56 milhões. Mas o maior número absoluto de toda a eleição é de governador — Tarcísio, 14,5 milhões."

**Explique a diferença:** "Deputado federal tem 7.262 candidatos. Governador tem 182. Comparar os dois é comparar laranja com banana."

---

### Tela 10 — Dinâmica 3: aposta
**Como conduzir:** "Quem a turma acha que foi o mais votado pra deputado federal? Grita."
Marque no quadro. Aí clica em **Revelar**.

**Fala de fechamento:** "Nikolas Ferreira, 3,1 milhões. E o segundo ficou a 81 mil votos. Ou seja: quase empatado, e a diferença é menor que 3%."

> Se a turma não engajar, pule. Não insista.

---

### Tela 11 — Dinâmica 4: 60 segundos
**Como conduzir:**
1. "Em dupla, 60 segundos. Levanta 3 hipóteses de por que a Paraíba lidera."
2. Clica em **Iniciar 60s**. Deixa o cronômetro correr na tela.
3. Para em 20s: "quem quer falar?" Ouça 2 respostas.
4. Aí vira o card da direita: **"o que o dado sustenta e o que é achismo."**

**Fala:** "O dado sustenta que a PB tem o maior % de nulos e o maior % de nulos+brancos. O dado **não** sustenta 'porque o povo é desinformado' — o TSE não mede escolaridade de quem anulou. Isso seria invenção minha."

**Essa é a frase que separa trabalho bom de trabalho nota 10.**

---

### Tela 12 — Interpretação + limites
**Fala:** as 3 leituras em 40 segundos. Depois **pare** e leia os 3 cards vermelhos devagar.

**Não esconda o limite do 1º turno.** Diga na frente: "o 2º turno de 25/10 não estava nos dados abertos quando eu puxei. Se o professor quiser, eu atualizo."

---

### Tela 13 — Fontes e fechamento
Deixe na tela e responda perguntas com ela aberta. A pergunta final ("quem ganha com 4,77% de voto jogado fora?") é sua deixa pra encerrar — **não responda você mesmo**, jogue pra turma.

---

## 3. Perguntas que a banca vai fazer (e a resposta curta)

| Pergunta | Resposta em 1 frase |
|---|---|
| "De onde vieram esses dados?" | "Dados abertos do TSE, dataset `resultados-2026`, dois arquivos: detalhe da votação por município/zona e votação por candidato." |
| "Por que só 1º turno?" | "Porque os arquivos publicados até a consulta tinham 100% das linhas com turno = 1, mesmo gerados em 25/10." |
| "Isso é amostra ou censo?" | "Censo. São todos os votos apurados, não tem estimativa." |
| "Nulo e branco são a mesma coisa?" | "Não. Branco é abstenção de escolha; nulo é anulação. Nenhum dos dois conta pra eleição." |
| "Por que a Paraíba?" | "O dado mostra o padrão, não a causa. O TSE não informa motivo da anulação." |
| "Por que o Senado tem o dobro?" | "Duas cadeiras por estado — o eleitor vota duas vezes." |
| "Você usou IA?" | `[SUA DECISÃO]` — responda o que for verdade. Se usou pra organizar, diga. O dado é oficial e você conferiu. |

---

## 4. Checklist 10 minutos antes

- [ ] Abrir o HTML e dar `F11`
- [ ] Testar `←` `→` nas telas 1 e 13 (pra não travar na hora)
- [ ] Testar o **+** da dinâmica 1 e o **Iniciar 60s**
- [ ] Zerar a contagem da dinâmica 1 (botão "Zerar contagem")
- [ ] Deixar o roteiro impresso ou no celular — **não** na mesma tela do deck
- [ ] Conferir se o projetor não corta a barra de navegação embaixo

---

## 5. O que eu NÃO escrevi de propósito (decisão sua)

1. **A tese central.** O deck mostra dois rankings e um limite. Você decide se a mensagem é "cuidado com ranking", "o eleitor anula mais do que branqueia" ou "transparência de dados". Escolha **uma** e repita no fechamento.
2. **O tom político.** Não há nenhuma leitura partidária no deck, de propósito. Se você quiser comentar o resultado eleitoral em si (quem ganhou), é fala sua — e é risco seu.
3. **A comparação com 2022.** Não incluí porque não puxei os dados de 2022. Se quiser evolução histórica, me peça que eu busco.
4. **O 2º turno.** Não está nos dados abertos. Se for obrigatório, avise que precisa de outra fonte.
5. **A conclusão sobre a Paraíba.** O dado não explica. Qualquer explicação é hipótese — e hipótese tem que ser dita como hipótese.

---

## 6. Fonte (para colar no slide de referência do trabalho)

- TSE. **Resultados — 2026**. Portal de Dados Abertos do Tribunal Superior Eleitoral. Disponível em: `https://dadosabertos.tse.jus.br/dataset/resultados-2026`. Acesso em: 27 out. 2026.
  - Arquivos: `detalhe_votacao_munzona_2026.zip` e `votacao_candidato_munzona_2026.zip` (gerados em 25/10/2026).

> Regra do projeto: não inventar referência. Se precisar de bibliografia teórica (ex.: comportamento eleitoral, voto nulo), **eu não vou inventar autor** — me diga o tema e eu procuro fonte real, ou você traz a sua.
