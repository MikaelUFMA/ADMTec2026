<div align="center">

<img src="assets/banner-pintec.svg" alt="PINTEC 17 — o mapa da inovação brasileira" width="880">

# PINTEC 17 — o mapa da inovação brasileira

**Dashboard que sai do papo e vai pro dado oficial: quanto o Brasil inova, quem inova, com que grana e com qual apoio.**

[![Abrir o dashboard](https://img.shields.io/badge/ABRIR%20O%20DASHBOARD-index.html-c6ff4a?style=for-the-badge&labelColor=070b18)](index.html)
[![Fonte](https://img.shields.io/badge/FONTE-SIDRA%2FIBGE%20API%20v3-4de1ff?style=for-the-badge&labelColor=070b18)](https://servicodados.ibge.gov.br/api/v3/agregados)
[![Edição](https://img.shields.io/badge/EDI%C3%87%C3%83O-2017%20(tri%C3%AAnio%202015--2017)-ff4ecd?style=for-the-badge&labelColor=070b18)](#de-onde-vem-cada-número)

</div>

---

## Sobre o projeto

Esse repositório tem duas coisas que andam juntas:

1. **Uma skill do OpenCode** (`.opencode/skills/ibge_pintec_analyzer/`) que consulta a **API v3 do SIDRA/IBGE**, valida os números e monta um JSON normalizado.
2. **Um dashboard em página única** (`index.html`) que lê esse JSON, joga tudo em gráficos e tabelas e conta a história da inovação no Brasil sem enrolação.

Nada de número copiado de notícia, print de slide ou "ouvi falar". Todo valor no painel sai de uma tabela do SIDRA, e cada card mostra de qual tabela e variável ele veio.

> **Resumo do retrato 2017:** de **116.962** empresas do recorte, **39.329** inovaram — **33,63%**. Elas gastaram **R$ 67,33 bilhões** em atividades inovativas, sendo **R$ 25,62 bi** em P&D interno. Só **600** colocaram algo novo pro mundo.

---

## O que tem dentro do painel

| Seção | O que responde |
| --- | --- |
| **Retrato** | Empresas, inovadoras, taxa, dispêndios, P&D e série 2008→2017 |
| **Setores** | Ranking das divisões industriais por taxa de inovação, com busca e ordenação |
| **O que é novo** | Produto x processo, grau de novidade (empresa / mercado / mundo), fatia da receita |
| **Apoio & travas** | Programas de governo que chegaram nas empresas e os 12 obstáculos declarados |
| **Tabela** | Os 29 recortes de divisão com todos os indicadores, filtrável e ordenável |
| **Ficha técnica** | Fonte primária, limites do dado, comando pra reproduzir e JSON pra baixar |

Recursos de interface:

- tema **escuro/claro** com persistência em `localStorage`;
- contadores animados, revelação por scroll e gráficos que redesenham na troca de tema;
- **Tailwind CSS** (CDN) + **Chart.js** (CDN), zero build de front-end;
- ilustrações e mascote em **SVG inline** (a Lume), sem dependência de imagem externa;
- dados **embutidos no HTML** — abre com duplo clique, sem servidor e sem `fetch` bloqueado por CORS.

---

## De onde vem cada número

Fonte única: **API de Agregados v3 do SIDRA/IBGE** — <https://servicodados.ibge.gov.br/api/v3/agregados>.

| Tabela | Conteúdo usado no painel | Link oficial |
| --- | --- | --- |
| **5018** | Receita, dispêndios, P&D interno, empresas com P&D | <https://sidra.ibge.gov.br/tabela/5018> |
| **5453** | Total de empresas e empresas inovadoras por atividade | <https://sidra.ibge.gov.br/tabela/5453> |
| **5458** | Grau de novidade do principal produto/processo | <https://sidra.ibge.gov.br/tabela/5458> |
| **5618** | Faixas de participação de produtos novos nas vendas | <https://sidra.ibge.gov.br/tabela/5618> |
| **5924** | Apoio do governo por tipo de programa | <https://sidra.ibge.gov.br/tabela/5924> |
| **5926** | Fatores que prejudicaram as atividades inovativas | <https://sidra.ibge.gov.br/tabela/5926> |

- **Pesquisa:** PINTEC — Pesquisa de Inovação, edição **2017** (triênio **2015–2017**).
- **Períodos disponíveis nessas tabelas:** 2008, 2011, 2014 e 2017. Confirmado em `/periodos` antes de montar os gráficos.
- **Unidades:** empresas em *Unidades*; valores monetários convertidos de *Mil Reais* para **R$ bilhões** (÷ 1.000.000); percentuais calculados a partir das contagens.
- **Data da consulta registrada no painel:** 27/10/2026 (campo `meta.consultado_em` do JSON).

### Números-chave (2017)

| Indicador | Valor | Origem |
| --- | ---: | --- |
| Empresas no recorte | 116.962 | 5453 |
| Empresas que inovaram | 39.329 | 5453 |
| Taxa de inovação | 33,63% | 5453 |
| Receita líquida de vendas | R$ 3.449,17 bi | 5018 |
| Dispêndios em atividades inovativas | R$ 67,33 bi | 5018 |
| P&D interno | R$ 25,62 bi | 5018 |
| Dispêndio / receita | 1,95% | cálculo sobre 5018 |
| P&D / dispêndio total | 38,06% | cálculo sobre 5018 |
| Empresas com apoio do governo | 10.290 (26,16% das inovadoras) | 5924 |
| Novidade só pra empresa | 17.044 | 5458 |
| Novidade pro mercado nacional | 4.414 | 5458 |
| Novidade pro mundo | 600 | 5458 |

Repare na assimetria: **43%** das inovadoras fizeram algo novo apenas pra própria empresa, enquanto a novidade radical (nova pro mundo) é **1,5%** do total de inovadoras.

---

## Como rodar

### Só ver o painel

Abra `index.html` no navegador. É isso. Os dados estão embutidos, então funciona por `file://`, pendrive, zip ou GitHub Pages.

```bash
# opcional: servir localmente
npx serve .
# ou
python -m http.server 8000
```

### Atualizar os dados (precisa de Node 18+)

```bash
# 1. busca tudo de novo na API oficial
node .opencode/skills/ibge_pintec_analyzer/scripts/fetch_pintec.mjs

# 2. reinjeta o JSON dentro do index.html
node scripts/build.mjs
```

O coletor aceita flags:

```bash
node .opencode/skills/ibge_pintec_analyzer/scripts/fetch_pintec.mjs --ano 2017 --out data/pintec.json
```

O que ele faz:

- consulta cada tabela e variável na API v3 (com retry e timeout);
- converte `".."`, `"..."` e `"X"` em `null` — **nunca** em zero;
- calcula taxa de inovação, dispêndio/receita e intensidade de P&D;
- grava `meta.tabelas` e `meta.consultado_em` pra auditoria;
- quebra com erro explícito se a API mudar de forma ou cair.

### Usar como skill do OpenCode

A skill fica em `.opencode/skills/ibge_pintec_analyzer/` e é autoinvocada quando o assunto é inovação/PINTEC. O passo a passo completo (checagem de edição, catálogo de agregados, checklist de validação e regras de gráfico) está em [`SKILL.md`](.opencode/skills/ibge_pintec_analyzer/SKILL.md).

---

## Estrutura do repositório

```text
.
├── index.html                        # dashboard completo (CSS, JS e dados embutidos)
├── README.md
├── assets/
│   ├── banner-pintec.svg             # banner deste README
│   ├── favicon.svg                   # ícone da aba
│   └── mascote-lume.svg              # mascote do painel
├── data/
│   └── pintec.json                   # dataset normalizado (fonte da verdade)
├── scripts/
│   └── build.mjs                     # injeta o JSON no index.html
└── .opencode/skills/ibge_pintec_analyzer/
    ├── SKILL.md                      # instruções da skill
    ├── references/sidra-api.md       # sintaxe e pegadinhas da API v3
    └── scripts/fetch_pintec.mjs      # coletor oficial
```

Formato resumido do `data/pintec.json`:

```jsonc
{
  "meta":   { "pesquisa": "...", "edicao": 2017, "trienio": "2015-2017", "tabelas": [...], "consultado_em": "..." },
  "serie":  [ { "ano": 2017, "empresas": 116962, "inovadoras": 39329, "taxa_inovacao": 33.63, ... } ],
  "resumo": { "dispendios_bi": 67.33, "pd_interno_bi": 25.62, ... },
  "setores": [ { "grupo": "...", "nome": "...", "empresas": 0, "taxa_inovacao": 0.0, ... } ],
  "tipos_inovacao": [...], "novidade": [...], "vendas": {...}, "apoio": [...], "obstaculos": [...]
}
```

---

## Limites do dado (leia antes de citar)

Esses avisos aparecem no próprio painel, na seção **Ficha técnica**, porque número sem contexto vira meme:

1. **É autodeclarado.** A empresa responde se inovou; não existe auditoria caso a caso. A PINTEC mede percepção declarada, não patente concedida.
2. **É trienal.** O "ano" 2017 representa o triênio **2015–2017**, não um retrato de 12 meses.
3. **Cobertura setorial limitada.** Fica fora do escopo: comércio, construção e boa parte dos serviços. Não é o Brasil inteiro.
4. **Valores correntes.** Os R$ são de 2017, sem deflacionamento. Comparar com valores de 2026 exige correção monetária.
5. **Mudança de recorte entre edições.** 2017 tem menos empresas no escopo que 2014, então a queda da taxa não é uma série limpa — parte do movimento é metodologia, não comportamento.
6. **Somas que não fecham.** Categorias de produto/processo se sobrepõem em algumas tabelas; o painel usa as categorias exclusivas da 5453 (produto e processo / só produto / só processo), que somam exatamente as 39.329 inovadoras.
7. **Edição mais recente no SIDRA.** Nas tabelas usadas, a série para em 2017. Se existir edição nova em outro agregado, **NÃO SEI** — é preciso conferir `/periodos` e o catálogo de agregados antes de afirmar.

---

## Stack

- **HTML + CSS + JavaScript vanilla** — sem framework, sem bundler.
- **Tailwind CSS** via CDN (utilitários) + CSS custom properties pro tema.
- **Chart.js** via CDN (barras, rosca, linha).
- **SVG inline** pra ilustrações, mascote e favicon.
- **Node.js 18+** apenas no lado dos scripts (`fetch` nativo, ESM, zero dependência).

---

## Créditos e uso

- Dados: **IBGE — Pesquisa de Inovação (PINTEC)**, via SIDRA/API v3. Cite o IBGE ao reutilizar.
- Código, layout e ilustrações: produzidos para este projeto.
- **Licença:** o repositório já traz um [`LICENSE`](../LICENSE) na raiz — **CC BY 4.0** (Creative Commons Atribuição 4.0 Internacional, © 2026 Tadeu Gomes Teixeira). Este painel é material derivado dentro desse repositório, então vale a mesma licença: reuso e adaptação liberados **com atribuição**. Antes de publicar fora do repositório, confirme com quem assina o projeto se a atribuição deve citar também a autoria do painel.

> Se algum ID de tabela ou variável mudar no SIDRA, **NÃO SEI** o novo valor: consulte `/api/v3/agregados`, confira os metadados e atualize o coletor.
