#!/usr/bin/env node
/**
 * Injeta data/pintec.json no bloco <script id="pintec-data"> do index.html.
 * Uso: node scripts/build.mjs
 */
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = process.cwd();
const dataPath = resolve(root, "data/pintec.json");
const htmlPath = resolve(root, "index.html");

const raw = await readFile(dataPath, "utf8");
const data = JSON.parse(raw); // falha cedo se o JSON estiver quebrado

const html = await readFile(htmlPath, "utf8");
const pattern = /<script id="pintec-data" type="application\/json">[\s\S]*?<\/script>/;
if (!pattern.test(html)) {
  throw new Error('Bloco <script id="pintec-data"> não encontrado no index.html.');
}

const next = html.replace(
  pattern,
  `<script id="pintec-data" type="application/json">${JSON.stringify(data)}</script>`,
);

await writeFile(htmlPath, next, "utf8");
const kb = (Buffer.byteLength(JSON.stringify(data)) / 1024).toFixed(1);
console.log(`✓ Dados de ${data.meta.pesquisa} ${data.meta.edicao} injetados no index.html (${kb} KB).`);
