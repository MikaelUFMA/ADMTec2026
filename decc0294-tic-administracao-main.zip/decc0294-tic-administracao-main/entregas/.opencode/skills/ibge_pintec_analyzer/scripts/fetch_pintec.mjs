#!/usr/bin/env node
/**
 * IBGE PINTEC Analyzer — coletor oficial SIDRA/IBGE
 * Uso: node .opencode/skills/ibge_pintec_analyzer/scripts/fetch_pintec.mjs
 * Saída: data/pintec.json
 */
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const BASE = "https://servicodados.ibge.gov.br/api/v3";
const ANO_PADRAO = "2017";

const args = process.argv.slice(2);
const getArg = (nome, fallback) => {
  const i = args.indexOf(nome);
  return i >= 0 && args[i + 1] ? args[i + 1] : fallback;
};

const ANO = getArg("--ano", ANO_PADRAO);
const OUT = resolve(process.cwd(), getArg("--out", "data/pintec.json"));

const TABELAS = {
  "5453": "Empresas, total e as que implementaram inovações e/ou com projetos, por atividades",
  "5018": "Variáveis selecionadas das empresas (receita, dispêndios, P&D)",
  "5458": "Empresas que implementaram inovações, por grau de novidade do principal produto e/ou processo",
  "5618": "Participação percentual dos produtos novos ou aprimorados nas vendas internas",
  "5924": "Empresas que receberam apoio do governo, por tipo de programa",
  "5926": "Fatores que prejudicaram as atividades inovativas",
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function getJSON(url, tentativas = 4) {
  let ultimoErro;
  for (let i = 1; i <= tentativas; i++) {
    try {
      const resp = await fetch(url, {
        headers: { Accept: "application/json", "User-Agent": "pintec-analyzer/1.0" },
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status} em ${url}`);
      return await resp.json();
    } catch (erro) {
      ultimoErro = erro;
      if (i < tentativas) await sleep(500 * i);
    }
  }
  throw new Error(`Falha ao consultar a API do IBGE: ${ultimoErro.message}`);
}

function numero(valor) {
  if (valor === null || valor === undefined) return null;
  const txt = String(valor).trim();
  if (["..", "...", "X", "-", ""].includes(txt)) return null;
  const n = Number(txt.replace(/\./g, "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

const bi = (milReais) => (milReais === null ? null : +(milReais / 1_000_000).toFixed(2));
const pct = (parte, todo) =>
  !parte || !todo ? null : +((parte / todo) * 100).toFixed(2);

function extrair(json, ano) {
  const mapa = new Map();
  for (const variavel of json) {
    for (const resultado of variavel.resultados ?? []) {
      const categoria = resultado.classificacoes?.find((c) => c.id === "696");
      const chave = categoria
        ? Object.keys(categoria.categoria)[0]
        : "total";
      const serie = resultado.series?.[0]?.serie ?? {};
      if (!mapa.has(chave)) mapa.set(chave, {});
      mapa.get(chave)[variavel.id] = numero(serie[ano]);
    }
  }
  return mapa;
}

function extrairSeries(json) {
  const saida = {};
  for (const variavel of json) {
    const resultado = variavel.resultados?.[0];
    const serie = resultado?.series?.[0]?.serie ?? {};
    saida[variavel.id] = Object.fromEntries(
      Object.entries(serie).map(([ano, valor]) => [ano, numero(valor)]),
    );
  }
  return saida;
}

// ---------------------------------------------------------------- série histórica
async function coletarSerie(edicoes) {
  const dados5453 = await getJSON(
    `${BASE}/agregados/5453/periodos/${edicoes.join("|")}/variaveis/630|5977?localidades=N1[all]&classificacao=696[33413]`,
  );
  const dados5018 = await getJSON(
    `${BASE}/agregados/5018/periodos/${edicoes.join("|")}/variaveis/5979|5980|5981|864?localidades=N1[all]&classificacao=696[33413]`,
  );
  const a = extrairSeries(dados5453);
  const b = extrairSeries(dados5018);
  return edicoes.map((ano) => {
    const empresas = a["630"]?.[ano] ?? null;
    const inovadoras = a["5977"]?.[ano] ?? null;
    const receitaMil = b["864"]?.[ano] ?? null;
    const dispendiosMil = b["5979"]?.[ano] ?? null;
    const pdMil = b["5981"]?.[ano] ?? null;
    return {
      ano: Number(ano),
      empresas,
      inovadoras,
      taxa_inovacao: pct(inovadoras, empresas),
      receita_bi: bi(receitaMil),
      dispendios_bi: bi(dispendiosMil),
      pd_interno_bi: bi(pdMil),
      empresas_pd: b["5980"]?.[ano] ?? null,
      dispendio_receita: pct(dispendiosMil, receitaMil),
      pd_sobre_dispendio: pct(pdMil, dispendiosMil),
    };
  });
}

// ---------------------------------------------------------------- retrato do ano
async function coletarRetrato(ano) {
  const [t5453, t5018, t5618, t5924, t5926, t5458] = await Promise.all([
    getJSON(
      `${BASE}/agregados/5453/periodos/${ano}/variaveis/630|5977|5982|5983|5984|5985|5988?localidades=N1[all]&classificacao=696[all]`,
    ),
    getJSON(
      `${BASE}/agregados/5018/periodos/${ano}/variaveis/5979|5980|5981|864?localidades=N1[all]&classificacao=696[all]`,
    ),
    getJSON(
      `${BASE}/agregados/5618/periodos/${ano}/variaveis/630|5982|6020|6021|6022?localidades=N1[all]&classificacao=696[33413]`,
    ),
    getJSON(
      `${BASE}/agregados/5924/periodos/${ano}/variaveis/6544?localidades=N1[all]&classificacao=729[all]`,
    ),
    getJSON(
      `${BASE}/agregados/5926/periodos/${ano}/variaveis/6545?localidades=N1[all]&classificacao=731[all]|701[33438]`,
    ),
    getJSON(
      `${BASE}/agregados/5458/periodos/${ano}/variaveis/5982?localidades=N1[all]&classificacao=696[33413]|711[all]`,
    ),
  ]);

  const esfera = extrair(t5453, ano);
  const financeiroPorSetor = extrair(t5018, ano);
  const total = esfera.get("33413") ?? {};
  const financeiro = financeiroPorSetor.get("33413") ?? {};

  // nomes oficiais das categorias da classificação 696
  const nomes696 = new Map();
  for (const variavel of t5453) {
    for (const r of variavel.resultados ?? []) {
      const cat = r.classificacoes?.find((c) => c.id === "696");
      if (!cat) continue;
      const [id, nome] = Object.entries(cat.categoria)[0] ?? [];
      if (id && nome) nomes696.set(id, nome);
    }
  }

  // setores (macro + divisões CNAE)
  const macroIds = new Map([
    ["129343", "Indústrias extrativas"],
    ["129344", "Indústrias de transformação"],
    ["129399", "Eletricidade e gás"],
    ["129400", "Serviços selecionados"],
  ]);

  const setores = [];
  for (const [id, empresa] of esfera) {
    if (id === "33413") continue;
    const nomeOriginal = nomes696.get(id);
    if (!nomeOriginal) continue;
    // só divisões CNAE (ex.: "10 FABRICAÇÃO...") e alguns blocos de serviços
    const ehDivisao =
      /^\d{2} [A-ZÀ-Ú]/.test(nomeOriginal) ||
      /^(58A|62|71|72) /.test(nomeOriginal);
    const ehMacro = macroIds.has(id);
    if (!ehDivisao && !ehMacro) continue;

    const fin = financeiroPorSetor.get(id) ?? {};
    const inovadoras = empresa["5977"];
    const dispendiosMil = fin["5979"];
    const pdMil = fin["5981"];
    setores.push({
      id,
      nome: ehMacro ? macroIds.get(id) : limparNome(nomeOriginal),
      nome_oficial: nomeOriginal,
      tipo: ehMacro ? "macro" : "divisao",
      grupo:
        ehMacro
          ? id === "129400"
            ? "Serviços"
            : "Indústria"
          : Number(id) >= 129400
            ? "Serviços"
            : "Indústria",
      empresas: empresa["630"],
      inovadoras,
      taxa_inovacao: pct(inovadoras, empresa["630"]),
      dispendios_bi: bi(dispendiosMil),
      pd_interno_bi: bi(pdMil),
      pd_sobre_dispendio: pct(pdMil, dispendiosMil),
    });
  }

  // composição exclusiva: só produto / só processo / ambos
  const produto = total["5982"];
  const processo = total["5985"];
  const ambos = total["5988"];
  const tipos = [
    { tipo: "Produto e processo", empresas: ambos, cor: "#7c3aed" },
    { tipo: "Só produto", empresas: produto !== null && ambos !== null ? produto - ambos : null, cor: "#06b6d4" },
    { tipo: "Só processo", empresas: processo !== null && ambos !== null ? processo - ambos : null, cor: "#f59e0b" },
  ];

  // novidade do principal produto (categorias de topo, sem somar subcategorias)
  const novidade = [];
  const novMap = [
    ["33535", "Novo para a empresa"],
    ["33538", "Novo para o mercado nacional"],
    ["33541", "Novo para o mundo"],
  ];
  for (const variavel of t5458) {
    for (const r of variavel.resultados ?? []) {
      const cat = r.classificacoes?.find((c) => c.id === "711");
      const id = cat ? Object.keys(cat.categoria)[0] : null;
      const rotulo = novMap.find(([k]) => k === id)?.[1];
      if (!rotulo) continue;
      novidade.push({
        categoria: rotulo,
        empresas: numero(r.series?.[0]?.serie?.[ano]),
      });
    }
  }

  // vendas
  const vendas = extrair(t5618, ano).get("33413") ?? {};

  // apoio do governo
  const apoio = [];
  for (const r of t5924[0]?.resultados ?? []) {
    const cat = r.classificacoes?.find((c) => c.id === "729");
    const id = cat ? Object.keys(cat.categoria)[0] : null;
    if (!id || id === "39279") continue;
    apoio.push({
      programa: cat.categoria[id],
      empresas: numero(r.series?.[0]?.serie?.[ano]),
    });
  }
  const apoioTotal = (t5924[0]?.resultados ?? [])
    .map((r) => {
      const cat = r.classificacoes?.find((c) => c.id === "729");
      return cat && Object.keys(cat.categoria)[0] === "39279"
        ? numero(r.series?.[0]?.serie?.[ano])
        : null;
    })
    .find((v) => v !== null);

  // obstáculos (alta importância)
  const obstaculos = (t5926[0]?.resultados ?? [])
    .map((r) => {
      const cat = r.classificacoes?.find((c) => c.id === "731");
      const id = cat ? Object.keys(cat.categoria)[0] : null;
      return {
        fator: id ? cat.categoria[id] : null,
        empresas: numero(r.series?.[0]?.serie?.[ano]),
      };
    })
    .filter((x) => x.fator && x.empresas !== null)
    .sort((a, b) => b.empresas - a.empresas);

  const empresas = total["630"];
  const inovadoras = total["5977"];
  const dispendiosMil = financeiro["5979"];
  const pdMil = financeiro["5981"];
  const receitaMil = financeiro["864"];

  return {
    resumo: {
      empresas,
      inovadoras,
      taxa_inovacao: pct(inovadoras, empresas),
      dispendios_bi: bi(dispendiosMil),
      pd_interno_bi: bi(pdMil),
      empresas_pd: financeiro["5980"],
      receita_bi: bi(receitaMil),
      dispendio_receita: pct(dispendiosMil, receitaMil),
      pd_sobre_dispendio: pct(pdMil, dispendiosMil),
      apoio_governo: apoioTotal,
      apoio_sobre_inovadoras: pct(apoioTotal, inovadoras),
      produtos_novos_mercado: novidade.find((n) => n.categoria === "Novo para o mercado nacional")?.empresas ?? null,
    },
    setores,
    tipos_inovacao: tipos,
    novidade,
    vendas: {
      empresas_produto: vendas["5982"],
      menos_10: vendas["6020"],
      de_10_a_40: vendas["6021"],
      mais_40: vendas["6022"],
    },
    apoio: apoio.sort((a, b) => b.empresas - a.empresas),
    obstaculos,
  };
}

function limparNome(nome) {
  const semCodigo = nome.replace(/^\d{2}(\.\d|[A-Z])?\s*/, "").trim().toLowerCase();
  return semCodigo.charAt(0).toUpperCase() + semCodigo.slice(1);
}

// ---------------------------------------------------------------- main
async function main() {
  console.log(`→ Consultando PINTEC ${ANO} na API v3 do SIDRA/IBGE...`);
  const periodos = await getJSON(`${BASE}/agregados/5453/periodos`);
  const edicoes = periodos.map((p) => String(p.id));
  if (!edicoes.includes(String(ANO))) {
    throw new Error(
      `A tabela 5453 não tem o período ${ANO}. Períodos disponíveis: ${edicoes.join(", ")}.`,
    );
  }
  console.log(`  Edições disponíveis no SIDRA: ${edicoes.join(", ")}`);
  const [serie, retrato] = await Promise.all([
    coletarSerie(edicoes),
    coletarRetrato(ANO),
  ]);

  const ultima = serie.find((s) => s.ano === Number(ANO));
  if (!ultima?.empresas) {
    throw new Error(`A API não retornou empresas para ${ANO}. Confira /periodos.`);
  }

  const resultado = {
    meta: {
      pesquisa: "Pesquisa de Inovação (PINTEC)",
      edicao: Number(ANO),
      trienio: `${Number(ANO) - 2}-${ANO}`,
      fonte: "IBGE — SIDRA / API v3",
      api: `${BASE}/agregados`,
      moeda: "R$ correntes do ano de referência (sem deflacionamento)",
      consultado_em: new Date().toISOString().slice(0, 10),
      tabelas: Object.entries(TABELAS).map(([id, nome]) => ({
        id,
        nome,
        sidra: `https://sidra.ibge.gov.br/tabela/${id}`,
        metadados: `${BASE}/agregados/${id}/metadados`,
      })),
      aviso:
        "Dados autodeclarados pela empresa. A PINTEC é trienal e a cobertura setorial não é universal. Não comparar edições sem considerar mudanças metodológicas.",
    },
    serie,
    ...retrato,
  };

  await mkdir(dirname(OUT), { recursive: true });
  await writeFile(OUT, JSON.stringify(resultado, null, 2), "utf8");
  console.log(`✓ Dados salvos em ${OUT}`);
  console.log(
    `  ${resultado.resumo.inovadoras} empresas inovadoras de ${resultado.resumo.empresas} (${resultado.resumo.taxa_inovacao}%)`,
  );
  console.log(`  Dispêndios: R$ ${resultado.resumo.dispendios_bi} bi | P&D: R$ ${resultado.resumo.pd_interno_bi} bi`);
}

main().catch((erro) => {
  console.error(`✗ ${erro.message}`);
  process.exit(1);
});
