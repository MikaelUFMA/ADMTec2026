# SIDRA API v3 — colinha

Base: `https://servicodados.ibge.gov.br/api/v3`

## Endpoints

| Endpoint | Para que serve |
| -------- | -------------- |
| `/agregados` | catálogo de pesquisas e tabelas |
| `/agregados/{tabela}/metadados` | nome, variáveis, classificações e categorias |
| `/agregados/{tabela}/periodos` | anos disponíveis |
| `/agregados/{tabela}/variaveis` | variáveis disponíveis |
| `/agregados/{tabela}/localidades/{nivel}` | recortes geográficos |
| `/agregados/{tabela}/periodos/{ano}/variaveis/{vars}?localidades=N1[all]` | dados |

## Sintaxe que funciona

```
.../5453/periodos/2017/variaveis/630|5977?localidades=N1[all]&classificacao=696[33413]
.../5926/periodos/2017/variaveis/6545?localidades=N1[all]&classificacao=731[39288]|701[33438]
```

- `|` separa variáveis **e** classificações.
- `[all]` traz todas as categorias.
- `[id1,id2]` traz categorias específicas.
- `N1[all]` = Brasil. `N3[all]` = UFs. `N6[all]` = municípios.

## Resposta

```json
[{
  "id": "5977",
  "variavel": "Número de empresas que implementaram inovações...",
  "unidade": "Unidades",
  "resultados": [{
    "classificacoes": [{ "id": "696", "categoria": { "33413": "Total" } }],
    "series": [{
      "localidade": { "id": "1", "nome": "Brasil" },
      "serie": { "2017": "39329" }
    }]
  }]
}]
```

## Valores especiais

| Símbolo | Significado |
| ------- | ----------- |
| `..` | não se aplica |
| `...` | não disponível |
| `X` | sigiloso |

Sempre normalizar para `null` antes de calcular.

## Observações

- A API não manda cabeçalho CORS liberado para todo mundo; para dashboard
  estático, baixe os dados e embuta no HTML.
- Não existe endpoint de "PINTEC 2022" nas tabelas 5453/5018; o último período
  retornado por `/periodos` é 2017.
- `Mil Reais` → bilhões: dividir por `1_000_000`.
