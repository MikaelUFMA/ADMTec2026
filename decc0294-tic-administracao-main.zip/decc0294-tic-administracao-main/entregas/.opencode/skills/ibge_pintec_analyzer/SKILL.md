---
name: IBGE PINTEC Analyzer
description: Consulta a API oficial do SIDRA/IBGE para extrair, validar e analisar os dados da Pesquisa de Inovação (PINTEC), gerando um JSON normalizado e um dashboard HTML. Use quando o pedido envolver inovação no Brasil, PINTEC, empresas inovadoras, dispêndios em P&D, apoio do governo à inovação ou obstáculos à inovação.
metadata:
  opencode/autoinvoke: true
---

# IBGE PINTEC Analyzer

Skill para puxar dados **oficiais** da Pesquisa de Inovação (PINTEC) direto da
API v3 do SIDRA/IBGE, sem copiar número de blog, notícia ou slide solto.

## Quando usar

- Pergunta sobre taxa de inovação das empresas brasileiras.
- Comparação entre edições da PINTEC (2008, 2011, 2014, 2017).
- Dispêndios em atividades inovativas e P&D interno.
- Apoio do governo, obstáculos à inovação, patentes, cooperação.
- Montagem de dashboard/apresentação com dados primários do IBGE.

## Regra de ouro

Nunca invente número. Todo valor exibido precisa carregar:

1. **tabela SIDRA** de origem (ex.: 5453);
2. **variável** (ex.: 5977);
3. **período** (ex.: 2017 — triênio 2015-2017);
4. **unidade** (Unidades, Mil Reais, %).

Se a API devolver `..`, `...`, `X` ou vazio, trate como **não disponível** e
declame a limitação. Não interpole.

## Workflow

### 1. Conferir a edição disponível

A PINTEC é trienal. Antes de qualquer gráfico, consulte:

```bash
curl "https://servicodados.ibge.gov.br/api/v3/agregados/5453/periodos"
```

No SIDRA, as tabelas principais da PINTEC cobrem **2008, 2011, 2014 e 2017**.
Se o pedido citar 2022 ou outro ano, confirme em `/periodos` antes de prometer.
Não use tabela de outra pesquisa como se fosse PINTEC.

### 2. Localizar o agregado certo

Use o catálogo oficial e filtre por nome:

```bash
curl "https://servicodados.ibge.gov.br/api/v3/agregados" > agregados.json
```

Tabelas usadas por esta skill:

| Tabela | Conteúdo |
| ------ | -------- |
| 5453 | Empresas, total e inovadoras, por atividade |
| 5018 | Variáveis selecionadas (receita, dispêndios, P&D) |
| 5458 | Grau de novidade do principal produto/processo |
| 5618 | Faixas de participação de produtos novos nas vendas |
| 5924 | Apoio do governo por tipo de programa |
| 5926 | Fatores que prejudicaram a inovação |

### 3. Rodar o coletor

Na raiz do projeto:

```bash
node .opencode/skills/ibge_pintec_analyzer/scripts/fetch_pintec.mjs
```

Saída padrão: `data/pintec.json`. O script:

- busca cada tabela e variável na API v3;
- normaliza `".."` para `null`;
- calcula taxa de inovação, dispêndio/receita e intensidade de P&D;
- mantém `meta.tabelas` e `meta.consultado_em` para auditoria;
- falha com erro claro se a API mudar ou ficar fora do ar.

Flags úteis:

```bash
node .../fetch_pintec.mjs --ano 2017 --out data/pintec.json
```

### 4. Validar antes de analisar

Checklist mínimo:

- [ ] `empresas` > `inovadoras` > 0.
- [ ] `taxa_inovacao` bate com `inovadoras / empresas * 100`.
- [ ] valores em `Mil Reais` foram convertidos para bilhões dividindo por 1.000.000.
- [ ] série histórica só com anos retornados pela API.
- [ ] nenhum `null` virou zero.

### 5. Analisar

Entregue nesta ordem:

1. **Brasão**: 1 parágrafo com o retrato do triênio.
2. **Números-chave**: empresas, inovadoras, taxa, dispêndios, P&D.
3. **Recortes**: setor, tipo de inovação, novidade, apoio público, obstáculos.
4. **Leitura crítica**: o que o dado NÃO diz (autodeclaração, triênio, cobertura
   setorial, mudança metodológica entre edições).
5. **Fonte**: link da tabela no SIDRA + data da consulta.

### 6. Gerar o dashboard

Use `index.html` (dashboard já montado) como base de layout, ou gere um novo a
partir do JSON. Regras:

- Dados **inline** no HTML (funciona abrindo o arquivo, sem servidor).
- Cada gráfico precisa de legenda com tabela/variável.
- Não use gráfico de pizza com mais de 5 fatias.
- Cores consistentes: uma cor por categoria em todos os gráficos.
- Mobile first: grid de 1 coluna abaixo de 768 px.
- Inclua link clicável para a tabela oficial no SIDRA.

## Armadilhas conhecidas

| Armadilha | Como evitar |
| --------- | ----------- |
| Achar que 2022 está no SIDRA | Checar `/periodos`; o conjunto 5453 para em 2017 |
| Somar "produto" + "processo" + "ambos" | Há sobreposição; use categorias exclusivas ou avise |
| Comparar 2017 com 2008 sem nota | Metodologia/cobertura mudou; declarar no rodapé |
| Usar `Mil Reais` como Reais | Dividir por 1.000.000 para bilhões |
| Tratar `..` como 0 | Converter para `null` e esconder do gráfico |

## Referências verificáveis

- API SIDRA v3: https://servicodados.ibge.gov.br/api/docs/agregados?versao=3
- Tabela 5453: https://sidra.ibge.gov.br/tabela/5453
- Tabela 5018: https://sidra.ibge.gov.br/tabela/5018
- PINTEC no IBGE: https://www.ibge.gov.br/estatisticas/multidominio/ciencia-tecnologia-e-inovacao/9141-pesquisa-de-inovacao.html

> Se algum desses links ou IDs mudar, **NÃO SEI** o novo valor: consulte o
> catálogo `/api/v3/agregados` e atualize esta skill.
